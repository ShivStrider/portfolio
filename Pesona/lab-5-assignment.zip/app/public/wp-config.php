<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'THyW*-1&v|s/Qh!lXM3lkB0^;<9E?e%C XPr%(}OyKk`YAoAoN`;KdSGKVXN8!WH' );
define( 'SECURE_AUTH_KEY',   'KiK<rr*]y.R=&KQ;tg=9x!0tpT`l=2Q,+YUJ0H |,)zBPN}idn,wf#CH@]oT!0r4' );
define( 'LOGGED_IN_KEY',     ').gvZ#Q(QwHgl(<)/gP-aHNUNKX8G4DH)|yzGOM-XJ-9)c|%]#9v|@PB`0vW+=23' );
define( 'NONCE_KEY',         'Y^&tf!7MPk)PDqFOF=f3~R&*5O^0*CargVsw{!chC7Q+rwTo@_|vHXkvX-p_=U%!' );
define( 'AUTH_SALT',         'sx^Jyx42,xlT4Yb8Fdsc)Xp+?eOA%LTvJxmQ>T6u@<8.58RktCm (o@d0? &_7SO' );
define( 'SECURE_AUTH_SALT',  ',qGOhNk|lqP|L#*[AA+9_a={8qBD^6kXkVx>uyC|*AX+k0akGuILR#iEmTpN3FWV' );
define( 'LOGGED_IN_SALT',    '8@La@=Xc%t9 mHOI`%|g+4*tA1&43FF] fhLOV(YgHCR5.fhRZsuTEQe1kn}$$^A' );
define( 'NONCE_SALT',        'DGjQ^,rYSz/D6m7l qJ.9-l=84D@.l2s8fnY1&#N2t8Z%[BIpSx8xMP<+^}*P(a_' );
define( 'WP_CACHE_KEY_SALT', 'z+b^.fvJlAp4Ej`3=r{2loX3cuuy8qH 6oK`kMU2n=oZ(3U1FM11t<Qsy~^4@:LO' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
